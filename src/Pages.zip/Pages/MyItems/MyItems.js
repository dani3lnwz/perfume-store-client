import React from 'react';

const MyItems = () => {
    return (
        <div>
            <h2>Hello</h2>
        </div>
    );
};

export default MyItems;